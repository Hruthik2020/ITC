

export class Doctor {

  doctorId: number;
  doctorName: string;
  speciality: string;
  location: string;
  hospitalName: string;
  mobileNo: string;
  email: string;
  type: String;
  bname:String;
  password: string;
  chargedPerVisit: DoubleRange;



}
